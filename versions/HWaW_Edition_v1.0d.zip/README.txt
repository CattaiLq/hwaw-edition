Plants vs. Zombies: HWaW Edition - тестовая сборка

Запуск: PlantsVsZombies_HWaW.exe
Нужен Windows 10/11. Все файлы из архива должны лежать в одной папке.

Сохранения лежат отдельно от обычной PvZ:
C:\ProgramData\PopCap Games\PlantsVsZombiesHWaW

Super Hard включен всегда.
Музыку для зомби "6-7" можно положить в папку sounds\sixseven (.ogg, .mp3 или .wav).

Если игра вылетела, рядом с exe появится crash.txt - пришлите его вместе с описанием, что вы делали.
